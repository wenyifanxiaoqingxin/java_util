package Demo.Test.PersonOne;

public class MonitoorUtil {

        public void invokeTime(long startTime,long endTime){

            System.out.println(String.format("方法执行的时间为%d", endTime-startTime));

        }
}
