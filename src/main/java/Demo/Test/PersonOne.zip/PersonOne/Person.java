package Demo.Test.PersonOne;

public interface Person {

    void giveMoney();
}
