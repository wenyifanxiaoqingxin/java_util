package Demo.Test.PersonOne;

public class test {

    public static  void  main(String[] args){

        Person person = new Student("小明");
        StudentProxy studentProxy = new StudentProxy(person);
        person  =  studentProxy.getProxys();
        person.giveMoney();
    }
}
